<template>
  <div class="page" id="PersonalChat">
    <van-nav-bar
      :title="username"
      fixed
      left-arrow
      @click-left="goBack" />

    <div class="personalChat-content"></div>

    <div class="personalChat-tools">
      <div class="personalChat-tools-editor">
        <input type="text" v-model="editText">
      </div>
      <button class="personalChat-tools-send">发送</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PersonalChat',
  data () {
    return {
      id: '', // 用户id
      username: '', // 用户名
      chatList: [ // 聊天内容
        { userid: '001', username: 'test1', avatar: require('@/assets/images/cat.jpg'), text: '你好', time: '2021-01-01' },
        { userid: '1', username: 'test', avatar: require('@/assets/images/cat.jpg'), text: '你好', time: '2021-01-01' }
      ],
      editText: '' // 正在编辑的文本
    }
  },
  methods: {
    // 返回
    goBack () {
      this.$router.go(-1)
    }
  },
  created () {
    this.id = this.$route.query.id
    this.username = this.$route.query.username
  }
}
</script>

<style lang="scss" scoped>
#PersonalChat {
  padding-top: 46px;
  padding-bottom: 41px;
}

.personalChat-content {
  overflow-y: auto;
  height: 100%;
  padding: 0.4rem;
  box-sizing: border-box;
}

.personalChat-tools {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 41px;
  padding: 0 20px;
  border-top: #EFEFEF solid 1px;
  box-sizing: border-box;

  &-editor {
    width: 70%;
    height: 34px;
    border: #EFEFEF solid 1px;
    border-radius: 18px;
    padding: 0 18px;
    box-sizing: border-box;

    input {
      width: 100%;
      height: 100%;
      border: none;
      outline: none;
    }
  }

  &-send {
    width: 40px;
    height: 26px;
    border: none;
    border-radius: 3px;
    outline: none;
    background: #07C160;
    color: #FFFFFF;
    font-size: 12px;

    &:active {
      background: #06AF57;
    }
  }
}
</style>
