<template>
  <div class="page" id="Chat">
    <div class="chat-header"></div>

    <div class="chat-news"></div>
  </div>
</template>

<script>
export default {
  name: 'Chat'
}
</script>

<style lang="scss" scoped>

</style>
