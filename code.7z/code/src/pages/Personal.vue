<template>
  <div class="page" id="Personal">
    <div class="personal-bg">
      <van-image
        width="20rem"
        height="10rem"
        fit="cover"
        :src="require('@/assets/images/bg.jpg')" />
    </div>

    <div class="personal-info">
      <div class="personal-info-avatar">
        <van-image
          width="4rem"
          height="4rem"
          fit="cover"
          :src="user.userAvatar" />
      </div>
      <div class="personal-info-right">
        <p class="personal-info-name">{{ user.username }}</p>
        <div class="personal-info-other">
          <div class="personal-info-record">
            <p>{{ user.attentionCount }}</p>
            <p>关注</p>
          </div>
          <div class="personal-info-record">
            <p>{{ user.praiseCount }}</p>
            <p>获赞</p>
          </div>
          <button class="personal-info-edit" @click="isInfoBox = true">编辑资料</button>
        </div>
      </div>
    </div>

    <div class="personal-list">
      <news-card
        v-for="(item, index) in list"
        :key="index"
        :title="item.title"
        :author="item.author"
        :cover="item.cover"
        :discussCount="item.discussCount"
        @click="goNewsDetails(item)" />
    </div>

    <edit-info-box :is-show.sync="isInfoBox" />
  </div>
</template>

<script>
import NewsCard from '@/components/NewsCard'
import EditInfoBox from '@/components/EditInfoBox'
import { customerInfor } from '@/model/api'

export default {
  name: 'Personal',
  data () {
    return {
      list: [ // 发布过的新闻
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        },
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        },
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        },
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        },
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        },
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        },
        {
          id: '000001', // 新闻id
          title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', // 新闻标题
          author: '呵呵', // 作者
          cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', // 封面图片地址
          discussCount: '299' // 评论数
        }
      ],
      isInfoBox: false // 是否显示个人信息编辑框
    }
  },
  methods: {
    // 前往新闻详情页
		goNewsDetails (row) {
			this.$router.push({
				path: '/NewsDetails',
				query: {
          id: row.id
        }
			})
		},
    // 获取个人信息
    getInfo () {
      customerInfor({
        user_id: this.user.id
      })
        .then(({ data, status }) => {
          if (status === 0) {
            this.$store.commit('setUser', {
              id: this.user.id,
              username: data.user_name,
              userAvatar: data.userAvatar,
              attentionCount: data.attentionCount || '0',
              praiseCount: data.praiseCount || '0',
              introduction: data.introduction,
              sex: data.sex,
              birthday: data.birthday
            })
          }
        })
        .catch(err => {
          this.$toast.fail('网络错误')
          throw err
        })
    }
  },
  computed: {
    // 用户信息
    user () {
      return this.$store.getters.getUser
    }
  },
  created () {
    this.getInfo()
  },
  components: {
    NewsCard,
    EditInfoBox
  }
}
</script>

<style lang="scss" scoped>
#Personal {
  position: relative;
  overflow-y: auto;
  padding-top: 8rem;
	background: #FFFFFF;
}

.personal-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 20rem;
  height: 10rem;
  filter: opacity(60%) saturate(150%);
}

.personal-info {
  display: flex;
  position: relative;
  height: 4rem;
  padding: 0 1rem;
  box-sizing: border-box;
  z-index: 1;

  &-avatar {
    overflow: hidden;
    width: 4rem;
    height: 4rem;
    border-radius: 50%;
    margin-right: 1rem;
    background: #FFFFFF;
  }

  &-right {
    flex-grow: 1;
  }

  &-name {
    height: 2rem;
    color: #FFFFFF;
    font-size: 18px;
    font-weight: bold;
    line-height: 2rem;
  }

  &-other {
    display: flex;
    align-items: center;
    height: 2rem;
  }

  &-record {
    width: 2.5rem;
    margin-right: 10px;
    color: #666666;
    font-size: 12px;
    font-weight: 600;
    text-align: center;
  }

  &-edit {
    height: 24px;
    padding: 0 5px;
    border: none;
    border-radius: 3px;
    margin-left: auto;
    color: #999999;
    font-size: 12px;
  }
}

.personal-list {
  padding: 0.3rem 0;
  margin-top: 20px;
  box-sizing: border-box;
}
</style>
