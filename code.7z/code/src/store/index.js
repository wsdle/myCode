import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const state = {
  userid: '', // 用户id
  username: '' // 用户名
}

const getters = {
  // 获取用户id
  getUserid (state) {
    return state.userid
  },
  // 获取用户名
  getUsername (state) {
    return state.username
  }
}

const mutations = {
  // 设置用户id
  setUserid (state, str) {
    state.userid = str
  },
  // 设置用户名
  setUsername (state, str) {
    state.username = str
  }
}

const actions = {}

const store = new Vuex.Store({ state, getters, mutations, actions })

export default store
