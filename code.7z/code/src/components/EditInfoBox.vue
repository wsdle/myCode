<template>
  <transition name="slide">
    <div v-show="isShow" class="editInfoBox">
      <van-nav-bar
        title="编辑资料"
        left-arrow
        fixed
        @click-left="closeBox" />

      <div class="editInfoBox-avatar">
        <div class="editInfoBox-upload">
          <van-image
            width="80"
            height="80"
            fit="cover"
            error-icon="photograph"
            :src="avatar" />
          <input
            class="editInfoBox-upload-input"
            ref="EditInfoBox_Upload"
            type="file"
            accept="image/*"
            @change="uploadAvatar">
        </div>
        <p>点击更换头像</p>
      </div>

      <van-cell-group>
        <van-field
          v-model="user"
          label="用户名"
          placeholder="请输入用户名"
          right-icon="arrow"
          input-align="right" />
        <van-field
          v-model="introduction"
          label="简介"
          placeholder="请输入简介"
          right-icon="arrow"
          input-align="right" />
        <van-field
          v-model="sex"
          label="性别"
          placeholder="请输入性别"
          right-icon="arrow"
          input-align="right"
          readonly
          @click="isPicker = true" />
        <van-field
          v-model="birthday"
          label="生日"
          placeholder="请输入生日"
          right-icon="arrow"
          input-align="right"
          readonly
          @click="isDatePicker = true" />
      </van-cell-group>

      <van-popup v-model="isPicker" round position="bottom">
        <van-picker
          show-toolbar
          :columns="['男', '女']"
          @cancel="isPicker = false"
          @confirm="confirmPicker" />
      </van-popup>

      <van-popup v-model="isDatePicker" round position="bottom">
        <van-datetime-picker
          type="date"
          :min-date="minDate"
          :max-date="maxDate"
          @cancel="isDatePicker = false"
          @confirm="confirmDatePicker" />
      </van-popup>
    </div>
  </transition>
</template>

<script>
import { DateFormat } from '@/model/common'

export default {
  props: {
    isShow: { // 是否显示
      type: Boolean,
      required: true
    },
    initAvatar: { // 初始头像
      type: String,
      default: ''
    },
    initUser: { // 初始用户名
      type: String,
      default: ''
    },
    initIntroduction: { // 初始简介
      type: String,
      default: ''
    },
    initSex: { // 初始性别
      type: String,
      default: '男'
    },
    initBirthday: { // 初始生日
      type: String,
      default: ''
    }
  },
  data () {
    return {
      fileList: [], // 头像文件列表
      avatar: this.initAvatar, // 头像预览地址
      user: this.initUser, // 用户名
      introduction: this.initIntroduction, // 简介
      sex: this.initSex, // 性别
      birthday: this.initBirthday, // 生日
      isPicker: false, // 是否显示选择器
      isDatePicker: false, // 是否显示时间选择器
      minDate: new Date(1950, 0, 1), // 最小日期
      maxDate: new Date(2050, 11, 31) // 最大日期
    }
  },
  methods: {
    // 关闭发送框
    closeBox () {
      this.$emit('update:is-show', false)
    },
    // 上传头像
    uploadAvatar () {
      const files = this.$refs.EditInfoBox_Upload.files
      if (files.length === 0) { return null }
      const reader = new FileReader()
      reader.onload = (e) => {
        this.avatar = e.target.result
      }
      reader.readAsDataURL(files[0])
    },
    // 选择器确认
    confirmPicker (value) {
      this.sex = value
      this.isPicker = false
    },
    // 日期选择器确认
    confirmDatePicker (value) {
      this.birthday = DateFormat(value, 'yyyy-MM-dd')
      this.isDatePicker = false
    }
  }
}
</script>

<style lang="scss" scoped>
.editInfoBox {
  position: fixed;
  top: 0;
  left: 0;
  overflow-y: auto;
  width: 100%;
  height: 100%;
	padding-top: 46px;
  background: #FFFFFF;
  box-sizing: border-box;
  z-index: 99;
  transform: translateX(0%);

  &-avatar {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 150px;
    color: #999999;
    font-size: 12px;

    /deep/ .van-uploader__upload,
    /deep/ .van-uploader__preview-image {
      border-radius: 50%;
      box-shadow: 0 0 5px #CCCCCC;
    }
  }

  &-upload {
    position: relative;
    overflow: hidden;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    margin-bottom: 5px;
    border-radius: 50%;
    border: #FFFFFF solid 1px;
    box-shadow: 0 0 10px #CCCCCC;

    &-input {
      position: absolute;
      top: 1px;
      left: 1px;
      width: 80px;
      height: 80px;
      opacity: 0;
    }
  }
}
</style>
