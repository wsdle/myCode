<template>
  <transition name="slide">
    <div v-show="isShow" class="newSendBox">
      <van-nav-bar
        left-arrow
        right-text="发布"
        fixed
        @click-left="closeBox"
        @click-right="release" />

      <div class="newSendBox-title">
        <van-field
          v-model="title"
          rows="1"
          autosize
          type="textarea"
          placeholder="请输入标题(5~30个字)" />
      </div>

      <div class="newSendBox-cover">
        <van-uploader v-model="cover" :max-count="1" />
      </div>

      <div class="newSendBox-content" :style="{ height: contentHeight + 'px' }">
        <rich-text-editor :content.sync="content" :height="contentHeight + 'px'" />
      </div>

      <!-- <div class="newSendBox-content">
        <van-field
          v-model="content"
          rows="10"
          autosize
          type="textarea"
          placeholder="请输入正文" />
      </div> -->
    </div>
  </transition>
</template>

<script>
import RichTextEditor from '@/components/RichTextEditor'

export default {
  props: {
    isShow: { // 是否显示
      type: Boolean,
      required: true
    }
  },
  data () {
    return {
      title: '', // 标题
      cover: [], // 图片文件
      content: '' // 文本内容
    }
  },
  watch: {
    isShow (val) {
      if (val) {
        this.title = ''
        this.cover = []
        this.content = ''
      }
    }
  },
  methods: {
    // 关闭发送框
    closeBox () {
      this.$emit('update:is-show', false)
    },
    // 发布
    release () {
      console.log(this.content)
      // 输入验证
      if (this.title.length < 5 || this.title.length > 30) {
        this.$dialog({ message: '标题错误，请输入5-30位标题' })
        return null
      }
      if (this.cover.length === 0) {
        this.$dialog({ message: '请上传封面图片' })
        return null
      }
      if (this.content.length === 0) {
        this.$dialog({ message: '请输入正文' })
        return null
      }

      // 加载提示
      const toast = this.$toast.loading({
        message: '加载中...',
        duration: 0
      })
      setTimeout(() => {
        toast.clear()
        this.closeBox()
      }, 1000)
    }
  },
  computed: {
    // 文本内容框高度
    contentHeight () {
      return innerHeight - 204
    }
  },
  components: {
    RichTextEditor
  }
}
</script>

<style lang="scss" scoped>
.newSendBox {
  position: fixed;
  top: 0;
  left: 0;
  overflow-y: auto;
  width: 100%;
  height: 100%;
	padding: 46px 1rem 0;
  background: #FFFFFF;
  box-sizing: border-box;
  z-index: 99;
  transform: translateX(0%);

  &-title {
    height: 70px;

    /deep/ .van-cell {
      padding-left: 0;
      padding-right: 0;
    }

    /deep/ textarea {
      display: block;
      width: 100%;
      border:  none;
      color: #333333;
      font-size: 16px;
      font-weight: 600;
    }
  }

  &-content {
    /deep/ .van-cell {
      padding-left: 0;
      padding-right: 0;
    }
  }
}
</style>
