<template>
  <transition name="slide">
    <div v-show="isShow" class="newSendBox">
      <van-nav-bar
        left-arrow
        right-text="发布"
        fixed
        @click-left="closeBox" />

      <div class="newSendBox-title">
        <van-field
          v-model="title"
          rows="1"
          autosize
          type="textarea"
          placeholder="请输入标题(5~30个字)" />
      </div>

      <div class="newSendBox-content">
        <van-field
          v-model="content"
          rows="10"
          autosize
          type="textarea"
          placeholder="请输入正文" />
      </div>

      <div class="newSendBox-cover">
        <van-uploader v-model="cover" :max-count="1" />
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  props: {
    isShow: { // 是否显示
      type: Boolean,
      required: true
    }
  },
  data () {
    return {
      title: '', // 标题
      cover: [], // 图片文件
      content: '' // 文本内容
    }
  },
  watch: {
    isShow (val) {
      if (val) {
        this.title = ''
        this.cover = []
        this.content = ''
      }
    }
  },
  methods: {
    // 关闭发送框
    closeBox () {
      this.$emit('update:is-show', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.newSendBox {
  position: fixed;
  top: 0;
  left: 0;
  overflow-y: auto;
  width: 100%;
  height: 100%;
	padding: 46px 1rem 0;
  background: #FFFFFF;
  box-sizing: border-box;
  z-index: 99;
  transform: translateX(0%);

  &-title {
    height: 70px;

    /deep/ .van-cell {
      padding-left: 0;
      padding-right: 0;
    }

    /deep/ textarea {
      display: block;
      width: 100%;
      border:  none;
      color: #333333;
      font-size: 16px;
      font-weight: 600;
    }
  }

  &-content {
    /deep/ .van-cell {
      padding-left: 0;
      padding-right: 0;
    }
  }
}
</style>
