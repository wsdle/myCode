<template>
  <div class="navBar">
    <div class="navBar-search">
      <div class="navBar-search-icon">
        <van-icon name="search" />
      </div>
      <input
        class="navBar-search-input"
        type="text"
        v-model="search"
        placeholder="搜索">
    </div>

    <div class="navBar-release" @click="onRelease">
      <van-icon name="plus" />
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      search: '' // 搜索内容
    }
  },
  methods: {
    // 发布
    onRelease () {
      this.$emit('on-release')
    }
  }
}
</script>

<style lang="scss" scoped>
.navBar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 46px;
  padding: 0 1rem;
  box-sizing: border-box;
  box-shadow: 0 0 3px #EEEEEE;

  &-search {
    position: relative;
    width: 8rem;
    height: 30px;
    padding-left: 30px;
    padding-right: 15px;
    border: #EFEFEF solid 1px;
    border-radius: 15px;

    &-icon {
      display: flex;
      justify-content: center;
      align-items: center;
      position: absolute;
      top: 0;
      left: 0;
      width: 30px;
      height: inherit;

      i {
        color: #999999;
        font-size: 18px;
      }
    }

    &-input {
      width: 100%;
      height: inherit;
      border: none;
    }
  }

  &-release {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 30px;
    height: 46px;

    i {
      color: #1989FA;
      font-size: 20px;
    }
  }
}
</style>
