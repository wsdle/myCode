<template>
  <div class="richTextEditor" :style="{ height }">
    <div
      class="richTextEditor-editor"
      ref="RichTextEditor_Editor"
      contenteditable
      @blur="changeFont">
    </div>
    <div class="richTextEditor-tools">
      <van-icon class-prefix="icon-editor" name="image" @mousedown.stop="uploaderImage" />
      <van-icon class-prefix="icon-editor" name="bold" @mousedown.stop="setFont('bold')" />
      <van-icon class-prefix="icon-editor" name="italic" @mousedown.stop="setFont('italic')" />
      <van-icon class-prefix="icon-editor" name="underline" @mousedown.stop="setFont('underline')" />
      <button @click="sumbit">send</button>
    </div>
    <input class="richTextEditor-uploader" ref="RichTextEditor_Uploader" type="file" accept="image/*" @change="insertImage">
  </div>
</template>

<script>
export default {
  props: {
    height: { // 文本框高度
      type: [String, Number],
      default: '3rem'
    }
  },
  data () {
    return {
      editorWidth: '', // 富文本框内容的宽度
      font: '', // 文本样式
      collapse: { // 光标位置记录
        startOffset: 0,
        startContainer: null,
        endOffset: 0,
        endContainer: null
      }
    }
  },
  methods: {
    // 变更选中文本样式
    changeFont () {
      // 记录光标位置
      const nodes = this.$refs.RichTextEditor_Editor.childNodes
      const collapse = document.getSelection().getRangeAt(0)
      nodes.forEach(item => { // 遍历内容节点,记录起始选区的节点及偏移位置
        if (item === collapse.startContainer) {
          this.collapse.startOffset = collapse.startOffset
          this.collapse.startContainer = collapse.startContainer
        }
        if (item === collapse.endContainer) {
          this.collapse.endOffset = collapse.endOffset
          this.collapse.endContainer = collapse.endContainer
        }
      })

      // 变更样式
      if (this.font === '') { return null }
      document.execCommand(this.font, false, null) // 编辑选择内容
      this.font = ''
    },
    // 设置将要对文本的操作
    setFont (style) {
      this.font = style
    },
    // 获取本地图片
    uploaderImage () {
      this.$refs.RichTextEditor_Uploader.click()
    },
    // 插入图片
    insertImage () {
      const files = this.$refs.RichTextEditor_Uploader.files
      if (this.$refs.RichTextEditor_Uploader.value === '' || files.length === 0) { return null }

      // 恢复光标位置
      this.$refs.RichTextEditor_Editor.focus()
      const selectiong = document.getSelection().getRangeAt(0)
      if (this.collapse.startContainer && this.collapse.endContainer) {
        selectiong.setStart(this.collapse.startContainer, this.collapse.startOffset)
        selectiong.setEnd(this.collapse.endContainer, this.collapse.endOffset)
      }

      // 处理图片大小后插入富文本编辑器
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        let cW = img.width
        let cH = img.height
        const maxWidth = this.editorWidth * 0.8 // 图片的最大宽度
        if (cW > maxWidth) {
          cW = maxWidth
          cH = maxWidth / img.width * cH
        }
        canvas.width = cW
        canvas.height = cH
        const ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, canvas.width, canvas.height)
        document.execCommand('insertImage', false, canvas.toDataURL('image/png'))
      }

      // 将文件转换位Base64
      const file = files[0]
      const reader = new FileReader()
      reader.onload = () => {
        img.src = reader.result
        this.$refs.RichTextEditor_Uploader.value = ''
      }
      reader.readAsDataURL(file)
    },
    // 数据提交
    sumbit () {
      console.dir(this.$refs.RichTextEditor_Editor.innerHTML)
    }
  },
  mounted () {
    // 获取富文本编辑器的内容宽度
    this.editorWidth = this.$refs.RichTextEditor_Editor.scrollWidth
  }
}
</script>

<style lang="scss" scoped>
.richTextEditor {
  overflow-y: auto;
  padding: 0.4rem;
  border: #DFDFDF solid 1px;
  box-sizing: border-box;

  &-editor {
    height: auto;
    min-height: 100%;
    letter-spacing: 1px;

    &:focus {
      outline: none;
    }

    /deep/ img {
      display: block;
      margin: 10px auto;
    }
  }

  &-tools {
    position: fixed;
    bottom: 50px;
    left: 0;
    right: 0;
    height: 1.8rem;
    padding: 0 1rem;
    background: #FFFFFF;
    z-index: 999999;
    box-shadow: 0 0 3px #EEEEEE;
    box-sizing: border-box;

    /deep/ .icon-editor {
      margin-right: 0.5rem;
      color: #999999;
      font-size: 0.77rem;
      line-height: 1.8rem;
    }
  }

  &-uploader {
    display: none;
  }
}
</style>
