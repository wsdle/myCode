import Vue from 'vue'
import Router from 'vue-router'
import store from '@/store'
import Container from '@/pages/Container'
import Login from '@/pages/Login'
import Home from '@/pages/Home'
import Chat from '@/pages/Chat'
import Personal from '@/pages/Personal'
import NewsDetails from '@/pages/NewsDetails'
import PersonalChat from '@/pages/PersonalChat'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/Login',
      name: 'Login',
      component: Login
    },
    {
      path: '/', // 框架
      name: 'Container',
      component: Container,
      redirect: '/Home',
      children: [
        {
          path: '/Home', // 主页
          name: 'Home',
          component: Home,
          meta: { authority: true }
        },
        {
          path: '/Chat', // 聊天
          name: 'Chat',
          component: Chat,
          meta: { authority: true }
        },
        {
          path: '/Personal', // 个人
          name: 'Personal',
          component: Personal,
          meta: { authority: true }
        }
      ]
    },
    {
      path: '/NewsDetails', // 新闻详情页
      name: 'NewsDetails',
      component: NewsDetails,
      meta: { authority: true }
    },
    {
      path: '/PersonalChat', // 个人聊天页
      name: 'PersonalChat',
      component: PersonalChat,
      meta: { authority: true }
    },
    {
      path: '*',
      redirect: '/Login'
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.path === '/Login') {
    next()
  } else if (to.meta.authority && !store.getters.getUser.id) {
    next({ name: 'Login' })
  } else {
    next()
  }
})

export default router
