/**
 * api接口统一管理
 */
import { get, post } from './http'

export const loginIn = p => get('/loginIn', p) // 登录
export const register = p => post('/register', p) // 注册
export const customerInfor = p => get('/CustomerInfor', p) // 获取个人页数据
