import Vue from 'vue'
import Router from 'vue-router'
import Container from '@/pages/Container'
import Home from '@/pages/Home'
import Personal from '@/pages/Personal'
import NewsDetails from '@/pages/NewsDetails'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/', // 框架
      name: 'Container',
      component: Container,
      redirect: '/Home',
      children: [
        {
          path: '/Home', // 主页
          name: 'Home',
          component: Home
        },
        {
          path: '/Personal', // 个人
          name: 'Personal',
          component: Personal
        }
      ]
    },
    {
      path: '/NewsDetails', // 新闻详情页
      name: 'NewsDetails',
      component: NewsDetails
    },
    {
      path: '*',
      redirect: '/'
    }
  ]
})

router.beforeEach((to, from, next) => {
  next()
})

export default router
