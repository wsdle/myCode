// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import '@/assets/scss/reset.scss'
import 'vant/lib/index.css'
import '@/assets/scss/global.scss'
import '@babel/polyfill'
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import Vant, { Dialog, Toast } from 'vant'
import axios from 'axios'
import Qs from 'qs'

Vue.use(Vant)

Vue.prototype.$dialog = Dialog
Vue.prototype.$toast = Toast
Vue.prototype.$axios = axios
Vue.prototype.$qs = Qs

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
