<template>
  <div class="page" id="NewsDetails">
    <van-nav-bar
      left-arrow
      fixed
      @click-left="goBack" />

    <h2 class="newsDetails-title">{{ details.title }}</h2>

    <div class="newsDetails-author">
      <div class="newsDetails-author-avatar">
        <img :src="details.authorAvatar" />
      </div>
      <div class="newsDetails-author-info">
        <p class="newsDetails-author-name">{{ details.author }}</p>
        <p class="newsDetails-author-time">{{ details.createTime }}</p>
      </div>

      <button
        v-show="!details.isAttention"
        class="newsDetails-author-attention"
        @click="details.isAttention = true">
        关注
      </button>
      <button
        v-show="details.isAttention"
        class="newsDetails-author-followed"
        @click="details.isAttention = false">
        已关注
      </button>
    </div>

    <div class="newsDetails-cover">
      <van-image
        width="100%"
        fit="contain"
        src="https://img01.yzcdn.cn/vant/cat.jpeg" />
    </div>

    <p class="newsDetails-content">{{ details.content }}</p>

    <div class="newsDetails-discuss">
      <p class="newsDetails-discuss-title">
        <span class="newsDetails-discuss-title-text">评论</span>
        <span class="newsDetails-discuss-title-count">({{ details.discussCount }})</span>
      </p>
      <ul class="newsDetails-discuss-list">
        <li
          v-for="(item, index) in discuss"
          :key="index"
          class="newsDetails-discuss-item">
          <div class="newsDetails-discuss-header">
            <div class="newsDetails-discuss-avatar">
              <img :src="item.userAvatar">
            </div>
            <span class="newsDetails-discuss-name">{{ item.user }}</span>
            <span class="newsDetails-discuss-time">{{ item.time }}</span>
          </div>
          <div class="newsDetails-discuss-content">
            <p>{{ item.text }}</p>
          </div>
        </li>
      </ul>
    </div>

    <div class="newsDetails-footer">
      <div class="newsDetails-footer-discuss">
        <div class="newsDetails-footer-discuss-icon">
          <van-icon name="edit" />
        </div>
        <input class="newsDetails-footer-discuss-input" type="text">
      </div>
      <span class="newsDetails-footer-send">发送</span>
      <div
        class="newsDetails-footer-praise newsDetails-footer-icon"
        :class="{ 'newsDetails-footer-lightUp': details.isPraise }"
        @click="details.isPraise = !details.isPraise">
        <van-icon name="good-job-o" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'NewsDetails',
  data () {
    return {
      details: { // 新闻信息
        title: '重磅！2021年全国两会召开时间定了！',
        author: '3DMGAME',
        authorAvatar: require('@/assets/images/cat.jpg'),
        isAttention: false, // 是否关注作者
        cover: 'https://img01.yzcdn.cn/vant/cat.jpeg',
        content: '12月26日，十三届全国人大常委会第二十四次会议，通过了关于召开第十三届全国人民代表大会第四次会议的决定，决定明确：十三届全国人大四次会议将于2021年3月5日在北京召开。政协第十三届全国委员会第四十七次主席会议，审议通过了关于召开政协第十三届全国委员会第四次会议的决定（草案），建议全国政协十三届四次会议于2021年3月4日在北京召开。\n会议还决定，2021年3月1日至2日召开全国政协十三届常委会第十五次会议，为召开全国政协十三届四次会议作准备。12月26日，十三届全国人大常委会第二十四次会议，通过了关于召开第十三届全国人民代表大会第四次会议的决定，决定明确：十三届全国人大四次会议将于2021年3月5日在北京召开。政协第十三届全国委员会第四十七次主席会议，审议通过了关于召开政协第十三届全国委员会第四次会议的决定（草案），建议全国政协十三届四次会议于2021年3月4日在北京召开。会议还决定，2021年3月1日至2日召开全国政协十三届常委会第十五次会议，为召开全国政协十三届四次会议作准备。\n会议还决定，2021年3月1日至2日召开全国政协十三届常委会第十五次会议，为召开全国政协十三届四次会议作准备。12月26日，十三届全国人大常委会第二十四次会议，通过了关于召开第十三届全国人民代表大会第四次会议的决定，决定明确：十三届全国人大四次会议将于2021年3月5日在北京召开。政协第十三届全国委员会第四十七次主席会议，审议通过了关于召开政协第十三届全国委员会第四次会议的决定（草案），建议全国政协十三届四次会议于2021年3月4日在北京召开。会议还决定，2021年3月1日至2日召开全国政协十三届常委会第十五次会议，为召开全国政协十三届四次会议作准备。',
        createTime: '2020-12-27 21:54:00', // 发表时间
        isPraise: false, // 是否点赞
        praiseCount: '3', // 点赞数
        discussCount: '3' // 评论数
      },
      discuss: [ // 新闻评论
        {
          user: '苏轼', // 用户名
          userAvatar: require('@/assets/images/cat.jpg'), // 用户头像
          text: '夜来幽梦忽还乡。小轩窗，正梳妆。相顾无言唯有泪千行。', // 评论文本
          time: '2020-01-01 10:00:00' // 发表时间
        },
        {
          user: '苏轼', // 用户名
          userAvatar: require('@/assets/images/cat.jpg'), // 用户头像
          text: '夜来幽梦忽还乡。小轩窗，正梳妆。相顾无言唯有泪千行。', // 评论文本
          time: '2020-01-01 10:00:00' // 发表时间
        },
        {
          user: '苏轼', // 用户名
          userAvatar: require('@/assets/images/cat.jpg'), // 用户头像
          text: '夜来幽梦忽还乡。小轩窗，正梳妆。相顾无言唯有泪千行。', // 评论文本
          time: '2020-01-01 10:00:00' // 发表时间
        }
      ]
    }
  },
  methods: {
    // 返回
    goBack () {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
#NewsDetails {
  overflow-y: auto;
  height: auto;
	padding: 46px 1rem 50px;
	background: #FFFFFF;
}

.newsDetails-title {
  margin: 0.5rem 0;
  font-size: 18px;
  font-weight: bold;
  line-height: 24px;
}

.newsDetails-author {
  display: flex;
  position: relative;
  margin-bottom: 0.5rem;

  &-avatar {
    overflow: hidden;
    width: 2.5rem;
    height: 2.5rem;
    border-radius: 50%;
    margin-right: 0.5rem;

    img {
      width: inherit;
      height: inherit;
    }
  }

  &-info {
    display: flex;
    flex-direction: column;
    justify-content: center;
    height: 2.5rem;
  }

  &-name {
    font-size: 14px;
    font-weight: 600;
  }

  &-time {
    color: #999999;
    font-size: 12px;
  }

  &-followed,
  &-attention {
    position: absolute;
    top: 50%;
    right: 0;
    width: 50px;
    height: 24px;
    border: transparent solid 1px;
    border-radius: 3px;
    background: #EEEEEE;
    color: #1989FA;
    transform: translateY(-50%);
  }

  &-attention {
    background: #EEEEEE;
    color: #1989FA;
  }

  &-followed {
    border-color: #DDDDDD;
    background: #FFFFFF;
    color: #DDDDDD;
  }
}

.newsDetails-cover {
  margin-bottom: 0.5rem;
}

.newsDetails-content {
  font-size: 12px;
  line-height: 24px;
  white-space: pre-wrap;
}

.newsDetails-discuss {
  margin-top: 30px;

  &-title {
    margin-bottom: 10px;
    line-height: 24px;

    &-text {
      font-size: 18px;
      font-weight: bold;
    }

    &-count {
      font-size: 16px;
      color: #CCCCCC;
    }
  }

  &-item {
    margin-bottom: 10px;
  }

  &-header {
    display: flex;
    align-items: center;
  }

  &-avatar {
    overflow: hidden;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    margin-right: 10px;

    img {
      width: inherit;
      height: inherit;
    }
  }

  &-name {
    font-weight: bold;
  }

  &-time {
    margin-left: auto;
    color: #999999;
    font-size: 12px;
  }

  &-content {
    padding-left: 40px;
    font-size: 12px;
    line-height: 18px;
    box-sizing: border-box;
  }
}

.newsDetails-footer {
  display: flex;
  align-items: center;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 40px;
  padding: 0 1rem;
  background: #FFFFFF;
  box-shadow: 0 0 3px #EEEEEE;

  &-discuss {
    position: relative;
    overflow: hidden;
    width: 8rem;
    height: 30px;
    padding-left: 30px;
    padding-right: 15px;
    border-radius: 15px;
    background: #EFEFEF;

    &-icon {
      display: flex;
      justify-content: center;
      align-items: center;
      position: absolute;
      top: 0;
      left: 0;
      width: 30px;
      height: inherit;

      i {
        color: #999999;
        font-size: 16px;
      }
    }

    &-input {
      width: 100%;
      height: inherit;
      border: none;
      background: transparent;
    }
  }

  &-send {
    margin-left: 10px;
    color: #1989FA;
    font-size: 12px;
  }

  &-icon {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 24px;
    height: 24px;

    i {
      color: #999999;
      font-size: 24px;
    }
  }

  &-lightUp i {
    color: #1989FA;
  }

  &-praise {
    margin-left: auto;
  }
}
</style>
