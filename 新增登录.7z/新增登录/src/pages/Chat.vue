<template>
  <div class="page" id="Chat"></div>
</template>

<script>
export default {
  name: 'Chat'
}
</script>

<style lang="scss" scoped>

</style>
