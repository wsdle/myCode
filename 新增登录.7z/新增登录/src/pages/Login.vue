<template>
  <div class="page" id="Login">
    <div class="login-logo">
      <img :src="require('@/assets/images/logo.png')">
      <span>Graduation Project</span>
    </div>

    <ul class="login-form">
      <li class="login-form-item">
        <span class="login-form-label">
          <van-icon name="user-circle-o" />
        </span>
        <input class="login-form-input" v-model="username" type="text" placeholder="请输入1-6位用户名">
      </li>
      <li class="login-form-item">
        <span class="login-form-label">
          <van-icon name="lock" />
        </span>
        <input class="login-form-input" v-model="password" type="password" placeholder="请输入6-18位密码">
      </li>
      <li v-if="status === 'registered'" class="login-form-item">
        <span class="login-form-label">
          <van-icon name="lock" />
        </span>
        <input class="login-form-input" v-model="confirm" type="password" placeholder="确认密码">
      </li>
    </ul>

    <p class="login-tips">{{ tips }}</p>

    <button v-if="status === 'login'" class="login-button" @click="login">登 录</button>
    <button v-if="status === 'registered'" class="login-button">注 册</button>

    <span v-if="status === 'login'" class="login-switch" @click="switchStatus('registered')">
      没有账号?
      <span class="login-switch-click">点击</span>
      注册账号
    </span>
    <span v-if="status === 'registered'" class="login-switch" @click="switchStatus('login')">返回登录</span>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data () {
    return {
      status: 'login', // 当前状态,login(登录)/registered(注册)
      username: '', // 用户名
      password: '', // 密码
      confirm: '', // 确认密码
      tips: '' // 提示
    }
  },
  methods: {
    // 切换状态
    switchStatus (status) {
      this.status = status
      this.username = ''
      this.password = ''
      this.confirm = ''
    },
    // 登录
    login () {
      this.$router.push('/Home')
    }
  }
}
</script>

<style lang="scss" scoped>
#Login {
  position: relative;
  overflow: hidden;
  padding: 0 10vw;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: url('~@/assets/images/login_bg.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    animation: bgZoom 15s linear infinite;
  }
}

.login-logo {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  position: relative;
  height: 30vh;

  img {
    width: 50%;
  }

  span {
    color: #F0F0F0;
    font-size: 0.77rem;
  }
}

.login-form {
  position: relative;
  overflow: hidden;
  width: 100%;
  height: auto;
  padding: 1rem 0;
  border-radius: 5px;
  margin: 0 auto;
  box-sizing: border-box;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #296dd4;
    opacity: 0.3;
  }

  &-item {
    position: relative;
    height: auto;
    padding-left: 2.5rem;
    padding-right: 1.2rem;
    margin-bottom: 1rem;
    box-sizing: border-box;
  }

  &-label {
    display: block;
    position: absolute;
    top: 0;
    left: 0.8rem;
    width: 1.2rem;
    height: 2rem;
    color: #FFFFFF;
    font-size: 1.2rem;
    text-align: center;
    line-height: 2rem;
  }

  &-input {
    width: 100%;
    height: 2rem;
    border: none;
    border-bottom: #FFFFFF solid 1px;
    outline: none;
    background: transparent;
    color: #FFFFFF;
    font-size: 0.77rem;
    letter-spacing: 2px;
    box-sizing: border-box;

    &::placeholder {
      color: #F0F0F0;
      font-size: 0.66rem;
    }
  }
}

.login-tips {
  position: relative;
  color: #bf1111;
  font-size: 0.66rem;
  text-align: right;
}

.login-button {
  position: relative;
  width: 100%;
  height: 2.22rem;
  border: none;
  border-radius: 5px;
  margin-top: 1rem;
  background: #296dd4;
  color: #FFFFFF;
  font-size: 0.9rem;

  &:active {
    background: #2361bf;
    user-select: none;
  }
}

.login-switch {
  position: absolute;
  bottom: 2rem;
  left: 50%;
  color: #FFFFFF;
  font-size: 0.66rem;
  letter-spacing: 2px;
  transform: translateX(-50%);

  &-click {
    color: #2c49b1;
  }
}

@keyframes bgZoom {
  0% {
    transform: scale(1, 1);
  }
  50% {
    transform: scale(1.5, 1.5);
  }
  100% {
    transform: scale(1, 1);
  }
}
</style>
