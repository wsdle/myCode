<template>
  <div class="page" id="Chat">
    <van-nav-bar
      title="聊天列表"
      fixed />

    <div class="chat-list">
      <chat-card
        v-for="item in list"
        :key="item.id"
        :username="item.username"
        :avatar="item.avatar"
        :info="item.info"
        :time="item.time"
        @on-click="goPersonalChat(item)" />
    </div>
  </div>
</template>

<script>
import ChatCard from '@/components/ChatCard'

export default {
  name: 'Chat',
  data () {
    return {
      list: [ // 聊天列表
        { id: '1', username: 'test1', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '2', username: 'test2', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '3', username: 'test3', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '4', username: 'test4', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '5', username: 'test5', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '6', username: 'test6', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '7', username: 'test7', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '8', username: 'test8', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '9', username: 'test9', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '10', username: 'test10', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '11', username: 'test11', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '12', username: 'test12', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '13', username: 'test13', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '14', username: 'test14', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' },
        { id: '15', username: 'test15', avatar: require('@/assets/images/cat.jpg'), info: 'Hello World!', time: '2021-04-02' }
      ]
    }
  },
  methods: {
    // 前往个人聊天页
    goPersonalChat (row) {
      this.$router.push({
        path: 'PersonalChat',
        query: {
          id: row.id,
          username: row.username
        }
      })
    }
  },
  components: {
    ChatCard
  }
}
</script>

<style lang="scss" scoped>
#Chat {
  padding-top: 46px;
  padding-bottom: 0.3rem;
}

.chat-list {
  overflow-y: auto;
  height: 100%;
}
</style>
