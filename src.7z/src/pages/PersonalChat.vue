<template>
  <div class="page" id="PersonalChat">
    <van-nav-bar
      :title="username"
      fixed
      left-arrow
      @click-left="goBack" />

    <div class="personalChat-list">
      <div
        class="personalChat-list-item"
        :class="{ 'personalChat-list-self': item.userid === user.id }"
        v-for="item in chatList"
        :key="item.userid">
        <div class="personalChat-list-avatar">
          <img :src="item.avatar">
        </div>
        <div class="personalChat-list-content">
          <div class="personalChat-list-info">
            <span class="personalChat-list-info-username">{{ item.username }}</span>
            <span class="personalChat-list-info-time">{{ item.time }}</span>
          </div>
          <div class="personalChat-list-text">{{ item.text }}</div>
        </div>
      </div>
    </div>

    <div class="personalChat-tools">
      <div class="personalChat-tools-editor">
        <input type="text" v-model="editText">
      </div>
      <button class="personalChat-tools-send">发送</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PersonalChat',
  data () {
    return {
      id: '', // 用户id
      username: '', // 用户名
      chatList: [ // 聊天内容
        { userid: '001', username: 'test1', avatar: require('@/assets/images/cat.jpg'), text: '你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好', time: '2021-01-01' },
        { userid: '1', username: 'test', avatar: require('@/assets/images/cat.jpg'), text: '你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好你好', time: '2021-01-01' }
      ],
      editText: '' // 正在编辑的文本
    }
  },
  methods: {
    // 返回
    goBack () {
      this.$router.go(-1)
    }
  },
  computed: {
    // 用户信息
    user () {
      return this.$store.getters.getUser
    }
  },
  created () {
    this.id = this.$route.query.id
    this.username = this.$route.query.username
  }
}
</script>

<style lang="scss" scoped>
#PersonalChat {
  padding-top: 46px;
  padding-bottom: 41px;
}

.personalChat-list {
  overflow-y: auto;
  height: 100%;
  padding: 0.6rem;
  background: #EFEFEF;
  box-sizing: border-box;

  &-item {
    display: flex;
    width: calc(100vw - 3.2rem);
    margin-bottom: 0.6rem;
  }

  &-avatar {
    flex-shrink: 0;
    flex-grow: 0;
    overflow: hidden;
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
    background: #FFFFFF;

    img {
      width: 100%;
    }
  }

  &-content {
    flex-shrink: 1;
    flex-grow: 1;
    padding-left: 0.4rem;
  }

  &-info {
    display: flex;
    font-size: 12px;
    line-height: 20px;

    &-username {
      letter-spacing: 1px;
    }

    &-time {
      margin-left: 0.4rem;
      color: #999999;
    }
  }

  &-text {
    display: inline-block;
    position: relative;
    width: auto;
    padding: 7px;
    border-radius: 5px;
    background: #FFFFFF;
    font-size: 14px;
    line-height: 16px;

    &::before {
      content: "";
      position: absolute;
      top: 15px;
      left: 0;
      width: 0;
      height: 0;
      border: 5px solid transparent;
      border-right: 5px solid #FFFFFF;
      transform: translate(-100%, -50%);
    }
  }

  &-self {
    flex-direction: row-reverse;
    margin-left: auto;

    .personalChat-list-content {
      padding-left: 0;
      padding-right: 0.4rem;
    }

    .personalChat-list-info {
      flex-direction: row-reverse;

      &-time {
        margin-right: 0.4rem;
        color: #999999;
      }
    }

    .personalChat-list-text {
      color: #FFFFFF;
      background: #07C160;

      &::before {
        display: none;
      }

      &::after {
        content: "";
        position: absolute;
        top: 15px;
        right: 0;
        width: 0;
        height: 0;
        border: 5px solid transparent;
        border-left: 5px solid #07C160;
        transform: translate(100%, -50%);
      }
    }
  }
}

.personalChat-tools {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 41px;
  padding: 0 20px;
  border-top: #EFEFEF solid 1px;
  box-sizing: border-box;

  &-editor {
    width: 70%;
    height: 34px;
    border: #EFEFEF solid 1px;
    border-radius: 18px;
    padding: 0 18px;
    box-sizing: border-box;

    input {
      width: 100%;
      height: 100%;
      border: none;
      outline: none;
    }
  }

  &-send {
    width: 40px;
    height: 26px;
    border: none;
    border-radius: 3px;
    outline: none;
    background: #07C160;
    color: #FFFFFF;
    font-size: 12px;

    &:active {
      background: #06AF57;
    }
  }
}
</style>
