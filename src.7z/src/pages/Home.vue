<template>
	<div class="page" id="Home">
		<nav-bar @on-release="openSendBox" />

		<van-tabs class="home-tabs" animated swipeable v-model="tabAcitve">
			<van-tab
				class="home-tab"
				v-for="(tab, index) in Object.keys(tabData)"
				:key="index"
				:title="tab">
				<van-pull-refresh v-model="isLoading" @refresh="onRefresh">
					<news-card
						v-for="item in tabData[tab]"
						:key="item.id"
						:title="item.title"
						:author="item.author"
						:cover="item.cover"
						:discussCount="item.discussCount"
						@click="openNewsDetails(item)" />
				</van-pull-refresh>
				<van-empty v-show="tabData[tab].length === 0" description="无内容" />
			</van-tab>
		</van-tabs>

		<news-details :is-show.sync="isNewsDetails"></news-details>
		<new-send-box :is-show.sync="isSendBox"></new-send-box>
	</div>
</template>

<script>
import NavBar from '@/components/NavBar'
import NewsCard from '@/components/NewsCard'
import NewsDetails from '@/components/NewsDetails'
import NewSendBox from '@/components/NewSendBox'

export default {
	name: 'Home',
	data () {
		return {
			tabAcitve: 0, // 当前选择的标签下标
			tabData: { // 标签页数据
				'推荐': [
					{ id: '000001', title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', author: '央视新闻', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '299' },
					{ id: '000002', title: '外媒：德军舰8月将穿航南海', author: '环球网', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '622' },
					{ id: '000003', title: '惨！走失哈士奇在派出所办案区打地铺', author: '中国国情', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '57' },
					{ id: '000004', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000005', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000006', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000007', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000008', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000009', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000010', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000011', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000012', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000013', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000014', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000015', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' }
				],
				'热点': [
					{ id: '000001', title: '央视网评 | “辣笔小球之流为何敢冒天下之大不韪？”', author: '央视新闻', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '299' },
					{ id: '000002', title: '外媒：德军舰8月将穿航南海', author: '环球网', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '622' },
					{ id: '000003', title: '惨！走失哈士奇在派出所办案区打地铺', author: '中国国情', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '57' },
					{ id: '000004', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000005', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000006', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000007', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000008', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000009', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000010', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000011', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000012', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000013', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000014', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' },
					{ id: '000015', title: '公司规定“做六休一”合法吗', author: '职场教练李麟', cover: 'https://img01.yzcdn.cn/vant/cat.jpeg', discussCount: '5' }
				],
				'体育': [],
				'娱乐': [],
				'财经': [],
				'科技': [],
				'数码': [],
				'军事': [],
				'旅游': []
			},
			isLoading: false, // 是否显示下拉加载动画
			isNewsDetails: false, // 是否显示新闻详情页
			isSendBox: false // 是否显示新闻发布弹窗
		}
	},
	methods: {
		// 下拉刷新
		onRefresh () {
			setTimeout(() => {
				this.$toast('刷新成功')
				this.isLoading = false
			}, 1000)
		},
		// 打开新闻发布框
		openSendBox () {
			this.isSendBox = true
		},
		// 前往新闻详情
		openNewsDetails (row) {
			this.isNewsDetails = true
		}
	},
	components: {
		NavBar,
		NewsCard,
		NewsDetails,
		NewSendBox
	}
}
</script>

<style lang="scss" scoped="scoped">
#Home {
	overflow-y: auto;
	padding-top: 46px;
	background: #FFFFFF;
}

.home-tabs {
	/deep/ .van-tabs__wrap {
		height: 30px;
		box-shadow: 0 0 3px #EEEEEE;
	}

	/deep/ .van-tabs__line {
		background-color: #1989FA;
	}
}

.home-tab {
	overflow-y: auto;
	height: calc(100vh - 126px);
	padding: 0.3rem 0;
	box-sizing: border-box;
}
</style>
