<template>
  <div class="page" id="Container">
    <keep-alive>
      <router-view />
    </keep-alive>

    <van-tabbar route>
      <van-tabbar-item replace to="/Home" icon="home-o">首页</van-tabbar-item>
      <van-tabbar-item replace to="/Chat" icon="chat-o">聊天</van-tabbar-item>
      <van-tabbar-item replace to="/Personal" icon="user-o">个人</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  name: 'Container',
  data () {
    return {
      active: 0 // 当前显示的页面下标
    }
  }
}
</script>

<style lang="scss" scoped>
#Container {
  padding-bottom: 50px;
}
</style>
