<template>
  <div class="chatCard" @click="onClick">
    <div class="chatCard-avatar">
      <img :src="avatar">
    </div>
    <div class="chatCard-content">
      <div class="chatCard-title">
        <span class="chatCard-title-text">{{ username }}</span>
        <span class="chatCard-title-time">{{ time }}</span>
      </div>
      <div class="chatCard-info van-ellipsis">{{ info }}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    username: { // 用户名
      type: String,
      required: true
    },
    avatar: { // 头像
      type: String,
      required: true
    },
    info: { // 消息
      type: String
    },
    time: { // 时间
      type: String
    }
  },
  methods: {
    // 点击事件
    onClick () {
      this.$emit('on-click')
    }
  }
}
</script>

<style lang="scss" scoped>
$height: 3.5rem; // 卡片高度
$paddingTop: 0.3rem; // 卡片上内边距
$avatarHeight: $height * 0.7; // 头像高度

.chatCard {
  position: relative;
  width: 100%;
  height: $height + $paddingTop;
  padding-top: $paddingTop;
  padding-left: $height;
  background: #FFFFFF;
  box-sizing: border-box;

  &:active {
    background: #F5F5F5;
  }

  &-avatar {
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    bottom: ($height - $avatarHeight) / 2;
    left: ($height - $avatarHeight) / 2;
    overflow: hidden;
    width: $avatarHeight;
    height: $avatarHeight;
    border-radius: 50%;

    img {
      width: 100%;
    }
  }

  &-content {
    height: $height;
    border-bottom: #EFEFEF solid 1px;
    margin-bottom: 0.5rem;
    box-sizing: border-box;
  }

  &-title {
    height: $height / 2;
    text-align-last: justify;
    line-height: $height / 2;

    &-text {
      color: #333333;
      font-size: 16px;
    }

    &-time {
      margin-right: 0.5rem;
      color: #999999;
      font-size: 12px;
    }
  }

  &-info {
    height: $height / 2;
    padding-right: 0.5rem;
    color: #666666;
    font-size: 12px;
    line-height: $height / 2;
    box-sizing: border-box;
  }
}
</style>
