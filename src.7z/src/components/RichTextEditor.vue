<template>
  <div class="richTextEditor" :style="{ height }">
    <div
      class="richTextEditor-editor"
      :class="{ 'richTextEditor-placeholder': !active && content === '' }"
      ref="RichTextEditor_Editor"
      contenteditable
      @focus="editorFocus"
      @blur="changeFont"
      @change="update">
    </div>

    <div class="richTextEditor-tools">
      <!-- <div class="richTextEditor-tools-icon" @mousedown.stop="uploaderImage">
        <van-icon class-prefix="icon-editor" name="image" />
      </div> -->
      <div class="richTextEditor-tools-icon" @mousedown.stop="setFont('bold')">
        <van-icon class-prefix="icon-editor" name="bold" />
      </div>
      <div class="richTextEditor-tools-icon" @mousedown.stop="setFont('italic')">
        <van-icon class-prefix="icon-editor" name="italic" />
      </div>
      <div class="richTextEditor-tools-icon" @mousedown.stop="setFont('underline')">
        <van-icon class-prefix="icon-editor" name="underline" />
      </div>
      <div class="richTextEditor-tools-icon" @mousedown.stop="setFont('justifyLeft')">
        <van-icon class-prefix="icon-editor" name="align-left" />
      </div>
      <div class="richTextEditor-tools-icon" @mousedown.stop="setFont('justifyCenter')">
        <van-icon class-prefix="icon-editor" name="align-center" />
      </div>
      <div class="richTextEditor-tools-icon" @mousedown.stop="setFont('justifyRight')">
        <van-icon class-prefix="icon-editor" name="align-right" />
      </div>
    </div>
    <input class="richTextEditor-uploader" ref="RichTextEditor_Uploader" type="file" accept="image/*" @change="insertImage">
  </div>
</template>

<script>
export default {
  props: {
    content: { // 富文本内容
      type: String,
      required: true
    },
    height: { // 富文本高度
      type: [String, Number]
    }
  },
  data () {
    return {
      editorWidth: '', // 富文本框内容的宽度
      font: '', // 文本样式
      collapse: { // 光标位置记录
        startOffset: 0,
        startContainer: null,
        endOffset: 0,
        endContainer: null
      },
      active: false // 记录文本框焦点
    }
  },
  watch: {
    content (val) {
      this.$refs.RichTextEditor_Editor.innerHTML = val
    }
  },
  methods: {
    // 获取文本框焦点
    editorFocus () {
      this.active = true
    },
    // 变更选中文本样式
    changeFont () {
      this.active = false

      // 记录光标位置
      this.saveCollapse()
      this.update()

      // 变更样式
      if (this.font === '') { return null }
      document.execCommand(this.font, false, null) // 编辑选择内容
      this.font = ''
      this.update()

      // 清除光标
      this.clearCollapse()
    },
    // 设置将要对文本的操作
    setFont (style) {
      this.font = style
    },
    // 记录光标位置
    saveCollapse () {
      const nodes = this.$refs.RichTextEditor_Editor.childNodes
      const collapse = document.getSelection().getRangeAt(0)
      nodes.forEach(item => { // 遍历内容节点,记录起始选区的节点及偏移位置
        if (item === collapse.startContainer) {
          this.collapse.startOffset = collapse.startOffset
          this.collapse.startContainer = collapse.startContainer
        }
        if (item === collapse.endContainer) {
          this.collapse.endOffset = collapse.endOffset
          this.collapse.endContainer = collapse.endContainer
        }
      })
    },
    // 恢复光标位置
    restoreCollapse () {
      this.$refs.RichTextEditor_Editor.focus()
      const selectiong = document.getSelection().getRangeAt(0)
      if (this.collapse.startContainer && this.collapse.endContainer) {
        selectiong.setStart(this.collapse.startContainer, this.collapse.startOffset)
        selectiong.setEnd(this.collapse.endContainer, this.collapse.endOffset)
      }
    },
    // 清除所有光标
    clearCollapse () {
      document.getSelection().removeAllRanges()
    },
    // 获取本地图片
    uploaderImage () {
      this.$refs.RichTextEditor_Uploader.click()
    },
    // 插入图片
    insertImage () {
      const files = this.$refs.RichTextEditor_Uploader.files
      if (this.$refs.RichTextEditor_Uploader.value === '' || files.length === 0) { return null }

      // 恢复光标位置
      this.restoreCollapse()

      // 处理图片大小后插入富文本编辑器
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        let cW = img.width
        let cH = img.height
        const maxWidth = this.editorWidth * 0.8 // 图片的最大宽度
        if (cW > maxWidth) {
          cW = maxWidth
          cH = maxWidth / img.width * cH
        }
        canvas.width = cW
        canvas.height = cH
        const ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, canvas.width, canvas.height)
        document.execCommand('insertImage', false, canvas.toDataURL('image/png'))
        this.update()
        this.clearCollapse()
      }

      // 将文件转换位Base64
      const file = files[0]
      const reader = new FileReader()
      reader.onload = () => {
        img.src = reader.result
        this.$refs.RichTextEditor_Uploader.value = ''
      }
      reader.readAsDataURL(file)
    },
    // 更新富文本内容
    update () {
      this.$emit('update:content', this.$refs.RichTextEditor_Editor.innerHTML)
    }
  },
  mounted () {
    // 获取富文本编辑器的内容宽度
    this.editorWidth = this.$refs.RichTextEditor_Editor.scrollWidth
  }
}
</script>

<style lang="scss" scoped>
.richTextEditor {
  overflow-y: auto;
  height: auto;
  padding: 0.4rem;
  padding-bottom: 40px;
  box-sizing: border-box;

  &-placeholder::after {
    content: "请输入正文";
    position: absolute;
    top: 0;
    left: 0;
    color: #CCCCCC;
  }

  &-editor {
    position: relative;
    height: auto;
    min-height: 100%;
    white-space: pre-wrap;
    letter-spacing: 1px;

    &:focus {
      outline: none;
    }

    /deep/ img {
      display: block;
      margin: 10px auto;
    }
  }

  &-tools {
    display: flex;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 40px;
    padding: 0 20px;
    background: #FFFFFF;
    z-index: 999999;
    box-shadow: 0 0 3px #EEEEEE;
    box-sizing: border-box;

    &-icon {
      width: 40px;
      height: 40px;
      text-align: center;
    }

    /deep/ .icon-editor {
      margin-right: 10px;
      color: #999999;
      font-size: 14px;
      line-height: 40px;
    }
  }

  &-uploader {
    display: none;
  }
}
</style>
