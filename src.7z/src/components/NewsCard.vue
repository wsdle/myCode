<template>
  <div class="newsCard" @click="onClick">
    <div class="newsCard-content">
      <div class="newsCard-info">
        <p class="newsCard-info-title van-multi-ellipsis--l2">{{ title }}</p>
        <div class="newsCard-info-footer">
          <span class="newsCard-info-author">{{ author }}</span>
          <span class="newsCard-info-discussCount">{{ discussCount }}评论</span>
        </div>
      </div>
      <div class="newsCard-cover">
        <van-image
          width="6rem"
          height="4.5rem"
          fit="contain"
          :src="cover" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    title: { // 标题
      type: String,
      default: '无标题'
    },
    author: { // 作者
      type: String,
      default: '佚名'
    },
    cover: { // 封面
      type: String,
      default: ''
    },
    discussCount: { // 评论数
      type: String,
      default: '0'
    }
  },
  methods: {
    // 点击事件
    onClick () {
      this.$emit('click')
    }
  }
}
</script>

<style lang="scss" scoped>
.newsCard {
  padding: 0 1rem;
  background: #FFFFFF;
  box-sizing: border-box;

  &:active {
    background: #F5F5F5;
  }

  &-content {
    display: flex;
    align-items: center;
    width: 100%;
    height: 100%;
    padding: 0.5rem 0;
    border-bottom: #EFEFEF solid 1px;
    box-sizing: border-box;
  }

  &-info {
    flex-grow: 1;
    flex-shrink: 1;
    position: relative;
    min-height: 4.5rem;
    padding-bottom: 20px;
    box-sizing: border-box;

    &-title {
      color: #333333;
      font-size: 14px;
      line-height: 18px;
      letter-spacing: 1px;
    }

    &-footer {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 20px;
      color: #999999;
      font-size: 12px;
      line-height: 20px;
    }

    &-author {
      margin-right: 0.3rem;
    }
  }

  &-cover {
    flex-grow: 0;
    flex-shrink: 0;
    width: 6rem;
    height: 4.5rem;
    padding-left: 0.8rem;
  }
}
</style>
