/*
* 日期时间格式化
* @params[Date] 待处理日期
* @params[String] 格式
*/
export function DateFormat (date, fmt) {
  const o = {
      'M+': date.getMonth() + 1, // 月份
      'd+': date.getDate(), // 日
      'h+': date.getHours(), // 小时
      'm+': date.getMinutes(), // 分
      's+': date.getSeconds(), // 秒
      'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
      'S': date.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  for (let k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
  }
  return fmt
}

/*
* 复制两层对象
* @params[Object] 待处理对象
*/
export function CopyObject (obj) {
  const res = {}
  for (let keys of Object.keys(obj)) {
    res[keys] = {}
    for (let key of Object.keys(obj[keys])) {
      res[keys][key] = obj[keys][key]
    }
  }
  return res
}
