/**
 * api接口统一管理
 */
import { get, post, upFile } from './http'

export const loginIn = p => get('/loginIn', p) // 登录
export const register = p => post('/register', p) // 注册
export const customerInfor = p => get('/CustomerInfor', p) // 获取个人页数据
export const updatePhoto = p => upFile('/updatePhoto', p) // 上传头像
export const updateCustomer = p => get('/updateCustomer', p) // 更改个人信息

export const selectByTab = p => get('/selectByTab', p) // 获取新闻列表
export const detailedArticle = p => get('/detailedArticle', p) // 获取新闻详细信息
export const publishArticle = p => post('/publishArticle', p) // 发布新闻
export const uploadDiscuss = p => post('/uploadDiscuss', p) // 发表评论
export const praiseUpload = p => post('/praiseUpload', p) // 新闻点赞
export const followCustomer = p => get('/followCustomer', p) // 关注用户
