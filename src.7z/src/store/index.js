import Vue from 'vue'
import Vuex from 'vuex'
import qs from 'qs'

Vue.use(Vuex)

const state = {
  user: { // 用户信息
    id: '1', // 用户id
    username: 'test', // 用户名
    userAvatar: require('@/assets/images/cat.jpg'), // 用户头像
    attentionCount: '', // 关注数
    praiseCount: '', // 获赞数
    introduction: '', // 简介
    sex: '', // 性别
    birthday: '' // 生日
  }
}

const getters = {
  // 获取用户信息
  getUser (state) {
    return !state.user.id ? qs.parse(sessionStorage.getItem('user')) : state.user
  }
}

const mutations = {
  // 设置用户id
  setUserid (state, str) {
    state.user.id = str
    sessionStorage.setItem('user', qs.stringify(state.user))
  },
  // 设置用户名
  setUsername (state, str) {
    state.user.username = str
    sessionStorage.setItem('user', qs.stringify(state.user))
  },
  // 设置用户信息
  setUser (state, obj) {
    for (let key of Object.keys(obj)) {
      state.user[key] = obj[key]
    }
    sessionStorage.setItem('user', qs.stringify(state.user))
  }
}

const actions = {}

const store = new Vuex.Store({ state, getters, mutations, actions })

export default store
